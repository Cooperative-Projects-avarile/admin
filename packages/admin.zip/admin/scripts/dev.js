const execSync = require('child_process').execSync;

execSync('npm run dev')