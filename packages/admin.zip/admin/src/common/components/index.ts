// 公用上传组件
export { default as UploadNormal } from "./uoloadNormal/uploadNormal";
// 动画文本
export { default as AnimateText } from "./animateText/animateText";
