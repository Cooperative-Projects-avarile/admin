import styles from "./style.module.scss";

const ConnectionPage = () => {


	return (
		<div className={styles.content}>
			welcome!
		</div>
	);
};

export default ConnectionPage;