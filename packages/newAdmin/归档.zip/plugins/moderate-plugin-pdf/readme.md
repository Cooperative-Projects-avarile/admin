# mderate-plugin-pdf

## 功能

支持 pdf 预览

## 插件依赖

```
"pdfjs-dist": "^4.0.379",
"react-pdf": "^7.7.1"
```

## 效果图

![分类](https://qiniu.moderate.run/plugins/moderate-plugin-pdf/QQ20210214-140334%E7%9A%84%E5%89%AF%E6%9C%AC.png)
