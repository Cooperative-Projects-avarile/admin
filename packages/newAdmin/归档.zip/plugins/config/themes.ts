import { dland } from "plugins/moderate-plugin-theme-dland/theme/dland";
//>>>THEME_INPORT_SIGN<<<//

export const pluginThemeMap = {
  dland,
  //>>>THEME_SIGN<<<//
};

export default pluginThemeMap;
