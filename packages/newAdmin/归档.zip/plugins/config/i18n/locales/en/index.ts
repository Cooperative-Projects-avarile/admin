import MusicPage from "plugins/moderate-plugin-music/i18n/en/MusicPage.json";
//>>>I18n_INPORT_SIGN<<<//
const pluginsResourcesEn = {
  MusicPage,
  //>>>I18n_SIGN<<<//
};
export default pluginsResourcesEn;
