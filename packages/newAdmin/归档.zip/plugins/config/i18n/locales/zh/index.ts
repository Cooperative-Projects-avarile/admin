import MusicPage from "plugins/moderate-plugin-music/i18n/zh/MusicPage.json";
//>>>I18n_INPORT_SIGN<<<//
const pluginsResourcesZh = {
  MusicPage,
  //>>>I18n_SIGN<<<//
};
export default pluginsResourcesZh;
