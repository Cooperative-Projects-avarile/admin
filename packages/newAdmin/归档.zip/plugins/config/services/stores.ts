export const stores = {
  //>>store<<//
};
