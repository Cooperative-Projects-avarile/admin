export const names = {};
