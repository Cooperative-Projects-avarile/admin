import { Wind } from "plugins/moderate-plugin-layout-wind/layouts/wind";
import { Rain } from "plugins/moderate-plugin-layout-rain/layouts/rain";
//>>>LAYOUT_INPORT_SIGN<<<//

export const pluginLayoutMap = {
  Wind,
  Rain,
  //>>>LAYOUT_SIGN<<<//
};
