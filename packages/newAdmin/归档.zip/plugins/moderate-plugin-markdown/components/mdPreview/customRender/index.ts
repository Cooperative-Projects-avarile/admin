export { default as customImg } from "./customImg";
