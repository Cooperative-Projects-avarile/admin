# mderate-plugin-markdown

## 功能

支持 MarkDown 文件的预览。

## 插件依赖

```
"react-markdown": "^9.0.1"
```

## 效果图

![分类](https://qiniu.moderate.run/plugins/moderate-plugin-winbox/Google%20Chrome.gif)
