# mderate-plugin-music

## 功能

支持 音乐播放 预览

## 插件依赖

无

## 效果图

![分类](https://qiniu.moderate.run/plugins/moderate-plugin-music/player/music.gif)
