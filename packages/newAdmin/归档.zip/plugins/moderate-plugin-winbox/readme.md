# mderate-plugin-winbox

## 功能

支持 pdf 预览

## 插件依赖

```
"react-winbox": "^1.5.0",
"winbox": "^0.2.82"
```

## 效果图

![分类](https://qiniu.moderate.run/plugins/moderate-plugin-winbox/Google%20Chrome.gif)
