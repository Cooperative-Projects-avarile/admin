export default (_: boolean) => {
	return {};
};
