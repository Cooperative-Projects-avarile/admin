import resourcesEn from "./en";
import resourcesZh from "./zh";

export default {
	en: resourcesEn,
	zh: resourcesZh,
};
