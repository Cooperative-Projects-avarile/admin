import ThemeSetting from "./themeSetting";

const MainSetting = () => {
	return (
		<>
			<ThemeSetting />
		</>
	);
};
export default MainSetting;
