export const ACTION_DICT = {
	ADD: { title: "添加", color: "#EAF4FE" },
	EDIT: { title: "编辑", color: "#EBF9F1" },
	DELETE: { title: "删除", color: "#FCEEED" },
	IMPORT: { title: "导入", color: "#FEF8E8" },
	EXPORT: { title: "导出", color: "#FEF8E8" },
};
