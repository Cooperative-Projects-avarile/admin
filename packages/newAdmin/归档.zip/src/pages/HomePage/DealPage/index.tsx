import { Outlet } from "react-router-dom";

const DealPage = () => {
	return (
		<>
			<Outlet></Outlet>
		</>
	);
};

export default DealPage;
