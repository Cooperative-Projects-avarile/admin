import styles from "./style.module.scss";

const MenuPage = () => {
	return (
		<div className={styles.content}>
			MenuPage welcome! TODO 菜单管理
			把若依的菜单完整集成过来，不改其规则，原滋原味的适配
		</div>
	);
};

export default MenuPage;
